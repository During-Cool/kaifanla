module.exports = [
  {
    type: "肉类",
    list: [
      {
        name: "红烧肉",
        calories: "350",
        protein: "15",
        carbs: "10",
        fat: "25",
        price: "58" // 估算价格
      },
      {
        name: "回锅肉",
        calories: "300",
        protein: "20",
        carbs: "15",
        fat: "15",
        price: "48" // 估算价格
      },
      {
        name: "糖醋排骨",
        calories: "280",
        protein: "18",
        carbs: "20",
        fat: "12",
        price: "52" // 估算价格
      },
      {
        name: "鱼香肉丝",
        calories: "180",
        protein: "15",
        carbs: "10",
        fat: "8",
        price: "42" // 估算价格
      },
      {
        name: "京酱肉丝",
        calories: "200",
        protein: "16",
        carbs: "12",
        fat: "10",
        price: "45" // 估算价格
      },
      {
        name: "木须肉",
        calories: "160",
        protein: "14",
        carbs: "8",
        fat: "6",
        price: "38" // 估算价格
      },
      {
        name: "梅菜扣肉",
        calories: "260",
        protein: "16",
        carbs: "18",
        fat: "14",
        price: "55" // 估算价格
      },
      {
        name: "粉蒸肉",
        calories: "220",
        protein: "17",
        carbs: "15",
        fat: "10",
        price: "48" // 估算价格
      },
      {
        name: "锅包肉",
        calories: "250",
        protein: "18",
        carbs: "22",
        fat: "10",
        price: "50" // 估算价格
      },
      {
        name: "水煮肉片",
        calories: "150",
        protein: "16",
        carbs: "5",
        fat: "6",
        price: "40" // 估算价格
      }
    ]
  },
  {
    type: "水产",
    list: [
      {
        name: "清蒸鱼",
        calories: "120",
        protein: "20",
        carbs: "2",
        fat: "4",
        price: "45" // 估算价格
      },
      {
        name: "红烧鱼",
        calories: "200",
        protein: "18",
        carbs: "8",
        fat: "10",
        price: "55" // 估算价格
      },
      {
        name: "白灼虾",
        calories: "100",
        protein: "20",
        carbs: "1",
        fat: "1",
        price: "68" // 估算价格
      },
      {
        name: "油焖大虾",
        calories: "180",
        protein: "18",
        carbs: "5",
        fat: "8",
        price: "78" // 估算价格
      },
      {
        name: "清蒸螃蟹",
        calories: "100",
        protein: "18",
        carbs: "2",
        fat: "2",
        price: "88" // 估算价格
      },
      {
        name: "香辣蟹",
        calories: "220",
        protein: "16",
        carbs: "10",
        fat: "12",
        price: "98" // 估算价格
      },
      {
        name: "剁椒鱼头",
        calories: "280",
        protein: "15",
        carbs: "5",
        fat: "20",
        price: "68" // 估算价格
      },
      {
        name: "酸菜鱼",
        calories: "150",
        protein: "18",
        carbs: "8",
        fat: "6",
        price: "52" // 估算价格
      },
      {
        name: "松鼠鱼",
        calories: "260",
        protein: "16",
        carbs: "15",
        fat: "18",
        price: "65" // 估算价格
      },
      {
        name: "水煮鱼",
        calories: "160",
        protein: "20",
        carbs: "4",
        fat: "7",
        price: "58" // 估算价格
      }
    ]
  },
  {
    type: "蔬菜",
    list: [
      {
        name: "地三鲜",
        calories: "150",
        protein: "4",
        carbs: "20",
        fat: "5",
        price: "32" // 估算价格
      },
      {
        name: "干煸豆角",
        calories: "200",
        protein: "6",
        carbs: "15",
        fat: "10",
        price: "36" // 估算价格
      },
      {
        name: "鱼香茄子",
        calories: "160",
        protein: "5",
        carbs: "12",
        fat: "7",
        price: "30" // 估算价格
      },
      {
        name: "麻婆豆腐",
        calories: "180",
        protein: "10",
        carbs: "8",
        fat: "10",
        price: "28" // 估算价格
      },
      {
        name: "小鸡炖蘑菇",
        calories: "150",
        protein: "15",
        carbs: "5",
        fat: "6",
        price: "46" // 估算价格
      },
      {
        name: "香菇油菜",
        calories: "100",
        protein: "4",
        carbs: "8",
        fat: "3",
        price: "26" // 估算价格
      },
      {
        name: "手撕包菜",
        calories: "120",
        protein: "3",
        carbs: "15",
        fat: "4",
        price: "22" // 估算价格
      },
      {
        name: "醋溜白菜",
        calories: "100",
        protein: "2",
        carbs: "12",
        fat: "3",
        price: "18" // 估算价格
      },
      {
        name: "清炒西兰花",
        calories: "80",
        protein: "4",
        carbs: "6",
        fat: "2",
        price: "28" // 估算价格
      },
      {
        name: "西红柿炒鸡蛋",
        calories: "120",
        protein: "6",
        carbs: "10",
        fat: "5",
        price: "22" // 估算价格
      }
    ]
  },
  {
    type: "主食",
    list: [
      {
        name: "米饭",
        calories: "130",
        protein: "3",
        carbs: "28",
        fat: "1",
        price: "3" // 估算价格
      },
      {
        name: "面条",
        calories: "180",
        protein: "6",
        carbs: "30",
        fat: "5",
        price: "15" // 估算价格
      },
      {
        name: "饺子",
        calories: "200",
        protein: "8",
        carbs: "25",
        fat: "8",
        price: "20" // 估算价格
      },
      {
        name: "包子",
        calories: "220",
        protein: "7",
        carbs: "30",
        fat: "8",
        price: "3"  // 估算价格，一个包子
      },
      {
        name: "馄饨",
        calories: "180",
        protein: "7",
        carbs: "25",
        fat: "6",
        price: "16" // 估算价格
      },
      {
        name: "烧饼",
        calories: "280",
        protein: "6",
        carbs: "40",
        fat: "10",
        price: "5" // 估算价格
      },
      {
        name: "油条",
        calories: "380",
        protein: "5",
        carbs: "35",
        fat: "20",
        price: "3" // 估算价格，一根油条
      },
      {
        name: "煎饼",
        calories: "260",
        protein: "7",
        carbs: "35",
        fat: "9",
        price: "8" // 估算价格
      },
      {
        name: "盖浇饭",
        calories: "250",
        protein: "10",
        carbs: "35",
        fat: "8",
        price: "20" // 估算价格
      },
      {
        name: "馒头",
        calories: "260",
        protein: "8",
        carbs: "50",
        fat: "3",
        price: "2" // 估算价格，一个馒头
      }
    ]
  },
  {
    type: "汤羹",
    list: [
      {
        name: "西湖牛肉羹",
        calories: "80",
        protein: "5",
        carbs: "5",
        fat: "2",
        price: "28" // 估算价格
      },
      {
        name: "紫菜蛋花汤",
        calories: "50",
        protein: "3",
        carbs: "4",
        fat: "1",
        price: "10" // 估算价格
      },
      {
        name: "酸辣汤",
        calories: "60",
        protein: "2",
        carbs: "5",
        fat: "3",
        price: "12" // 估算价格
      },
      {
        name: "冬瓜排骨汤",
        calories: "100",
        protein: "8",
        carbs: "4",
        fat: "5",
        price: "32" // 估算价格
      },
      {
        name: "罗宋汤",
        calories: "120",
        protein: "4",
        carbs: "10",
        fat: "6",
        price: "28" // 估算价格
      },
      {
        name: "玉米排骨汤",
        calories: "110",
        protein: "7",
        carbs: "8",
        fat: "5",
        price: "30" // 估算价格
      },
      {
        name: "鱼头豆腐汤",
        calories: "90",
        protein: "8",
        carbs: "3",
        fat: "4",
        price: "35" // 估算价格
      },
      {
        name: "海鲜豆腐汤",
        calories: "100",
        protein: "9",
        carbs: "4",
        fat: "4",
        price: "38" // 估算价格
      },
      {
        name: "蔬菜汤",
        calories: "70",
        protein: "3",
        carbs: "6",
        fat: "2",
        price: "18" // 估算价格
      },
      {
        name: "番茄鸡蛋汤",
        calories: "80",
        protein: "4",
        carbs: "7",
        fat: "3",
        price: "15" // 估算价格
      }
    ]
  }
];