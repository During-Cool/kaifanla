// pages/set/set.js
var util = require('../../utils/util.js')
var app = getApp()

Page({

   data: {
      custom_sound_default: false,
      custom_fast_select_default: false,
      custom_no_repetition_select_default: false,
      gdhw: [ //更多好玩的参数设置死的
         { 
            
         }
      ],
      showReport: false,
      reportData: null,
      mealList: [],
   },

   onLoad: function (options) {
      // var pages = getCurrentPages();
      // var Page = pages[pages.length - 1];//当前页
      // console.log(Page);
      // var prevPage = pages[pages.length - 2];  //上一个页面
      // var info = prevPage.data //取上页data里的数据也可以修改
      // prevPage.setData({ 键: 值 })//设置数据

      // 保持登录状态
      const user = wx.getStorageSync('userInfo');
      if (util.isNull(user)) {
        return;
      }
      this.setData({
        userInfo: user,
        userInfo_tank: false,
      });
   },

   onShow() {
    const user = wx.getStorageSync('userInfo');
    if (util.isNull(user)) {
      return;
    }

    // 把过去7天吃的菜取出来 
    const currentDate = new Date();
    const lastWeek = currentDate.setDate(currentDate.getDate() - 7);
    const lastWeekDate = new Date(lastWeek);

    const db = wx.cloud.database();
    const _ = db.command;
    const that = this;
    db.collection('mealRecord').where({
      _openid: user._openid,
      date: _.gt(lastWeekDate),
    }).get({
      success: function(res) {
        const mealInfos = res.data.map(item => {
          
          return {
            ...item.mealInfo,
            date: util.formatDate(item.date),
          }
          
        });
        // 计算各个参数
        let totalCal = 0;
        let totalFat = 0;
        let totalCarb = 0;
        let totalProtein = 0;

        mealInfos.forEach(item => {
          totalCal += Number(item.calories);
          totalFat += Number(item.fat);
          totalCarb += Number(item.carbs);
          totalProtein += Number(item.protein);
        });

        const formattedLastWeek = util.formatDate(lastWeekDate);
        const formattedNow = util.formatDate(new Date());
        const dateRangeStr = `${formattedLastWeek}~${formattedNow}`;
      
        that.setData({
          mealList: mealInfos,
          reportData: {
            totalCal,
            totalFat,
            totalCarb,
            totalProtein,
            dateRangeStr,
          }
        });
      }
    });
   },

   //声音
   switchChangeSound() {
      var that = this, custom_sound_default = that.data.custom_sound_default;
      app.globalData.musicflg = !app.globalData.musicflg ? true : false;
      that.setData({
         custom_sound_default: !custom_sound_default
      })
   },

   //快速决定
   switchChangeFastSelect() {
      var that = this, custom_fast_select_default = that.data.custom_fast_select_default;
      app.globalData.juedin = app.globalData.juedin ? false : true;
      that.setData({
         custom_fast_select_default: !custom_fast_select_default
      })
   },

   //不重复抽取
   switchChangeNoRepetitionSelect() {
      var that = this, custom_no_repetition_select_default = that.data.custom_no_repetition_select_default;
      app.globalData.repeat = !app.globalData.repeat ? true : false;
      that.setData({
         custom_no_repetition_select_default: !custom_no_repetition_select_default
      })
   },

   onShareAppMessage: function () {

   },
   //退出登录
   tuichu() {
      this.setData({
          userInfo: null,
      });

      wx.setStorageSync('userInfo', null);
    },
    /**
     * 关闭/打开弹框
     */
    closeTank(e) {
      if (!this.data.userInfo_tank) {
          wx.cloud.database().collection('user2')
              .get()
              .then(res => {
                  console.log("用户信息====", res);
                  if (res.data.length) {
                      this.setData({
                          userInfo: res.data[0],
                          userInfo_tank: false,
                      });

                      wx.setStorageSync('userInfo', res.data[0]);
                  } else {
                      console.log("还未注册====", res)
                      this.setData({
                          userInfo_tank: true
                      })
                  }
              }).catch(res => {
                  console.log('编程小石头提醒你请添加user2表')
              })
      } else {
          this.setData({
              userInfo_tank: false
          })
      }
  },
  /**
   * 获取头像
   */
  onChooseAvatar(e) {
    console.log(e);
    this.setData({
        avatarUrl: e.detail.avatarUrl
    })
  },
  /**
   * 获取用户昵称
   */
  getNickName(e) {
    console.log(e);
    this.setData({
        nickName: e.detail.value
    })
  },
  checkReport() {
    // 如果已显示 则隐藏
    if (this.data.showReport) {
      this.setData({
        showReport: false,
      });
      return;
    }

    // 检查是否登录
    if (!this.data.userInfo?.avatarUrl) {
      wx.showModal({
        title: '提示',
        content: '您还未登录，请先登录后再查看',
        confirmText: '去登录',
        complete: (res) => {
          if (res.cancel) {
            // do nothing
          }
      
          if (res.confirm) {
            this.closeTank();
          }
        }
      })
      return;
    }
    
    // 显示
    this.setData({
      showReport: true,
    });
  },
  /**
   * 提交
   */
  submit(e) {
    if (!this.data.avatarUrl) {
        return wx.showToast({
            title: '请选择头像',
            icon: 'error'
        })
    }
    if (!this.data.nickName) {
        return wx.showToast({
            title: '请输入昵称',
            icon: 'error'
        })
    }
    this.setData({
        userInfo_tank: false
    })
    wx.showLoading({
        title: '正在注册',
        mask: 'true'
    })
    let tempPath = this.data.avatarUrl

    let suffix = /\.[^\.]+$/.exec(tempPath)[0];
    console.log(suffix);

    //上传到云存储
    wx.cloud.uploadFile({
        cloudPath: 'userimg/' + new Date().getTime() + suffix, //在云端的文件名称
        filePath: tempPath, // 临时文件路径
        success: res => {
            console.log('上传成功', res)
            let fileID = res.fileID
            wx.hideLoading()
            wx.cloud.database().collection('user2')
                .add({
                    data: {
                        avatarUrl: fileID,
                        nickName: this.data.nickName
                    }
                }).then(res => {
                    let user = {
                        avatarUrl: fileID,
                        nickName: this.data.nickName
                    }
                    // 注册成功
                    console.log('注册成功')

                    this.setData({
                        userInfo: user,
                    });
                    
                    wx.setStorageSync('userInfo', user);
                }).catch(res => {
                    console.log('注册失败', res)
                    wx.showToast({
                        icon: 'error',
                        title: '注册失败',
                    })
                })

        },
        fail: err => {
            wx.hideLoading()
            console.log('上传失败', res)
            wx.showToast({
                icon: 'error',
                title: '上传头像错误',
            })
        }
    })
  },
})