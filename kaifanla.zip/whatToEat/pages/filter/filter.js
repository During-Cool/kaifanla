const foodsort = require("../../utils/foodsort");
const { getRandomElements, getRandomInteger } = require("../../utils/util");
const {
  filter
} = require("../../utils/xiaojueding");

// pages/filter/filter.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    modes: ['正常模式', '减脂', '增肌', '增脂'],
    currentMode: '正常模式',
    isNormalMode: true,
    priceRangeStart: '',
    priceRangeEnd: '',
    types: foodsort.map(item => item.type),
    foodType: foodsort[0].type,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
    console.log(foodsort)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  onModeChange: function (e) {
    const selectedMode = this.data.modes[e.detail.value];
    this.setData({
      currentMode: selectedMode,
      isNormalMode: selectedMode === '正常模式'
    });
  },

  onPriceRangeStartChange: function (e) {
    this.setData({
      priceRangeStart: e.detail.value
    });
    return e.detail.value;
  },
  onPriceRangeEndChange: function (e) {
    this.setData({
      priceRangeEnd: e.detail.value
    });
    return e.detail.value;
  },

  onFoodTypeChange: function (e) {
    const selectedType = this.data.types[e.detail.value];
    this.setData({
      foodType: selectedType
    });
  },

  submitForm: function () {
    const {
      currentMode,
      priceRangeStart,
      isNormalMode,
      foodType
    } = this.data;
    const formData = {
      mode: currentMode,
      priceRangeStart: priceRangeStart
    };

    if (isNormalMode) {
      formData.foodType = foodType;
    }

    console.log('提交的表单数据:', formData);
    // 可以将数据发送到服务器或进行其他处理
  },
  formSubmit(e) {
    const colorArr = [
      '#EE534F',
      '#FF7F50',
      '#FFC928',
      '#66BB6A',
      '#42A5F6',
      '#FF7F50',
      '#AA47BC',
      '#EC407A',
      '#DA70D6',
      '#FFA827',
      '#AA47BC',
      '#EE534F',
      '#42A5F6',
      '#66BB6A',
      '#FFC928',
      '#42A5F6',
      '#5C6BC0',
    ]

    console.log('form发生了submit事件，携带数据为：', e.detail.value);

    // 校验价格 下限不能高于上限 下限不可等于上限
    const {
      foodMode,
      priceStart,
      priceEnd,
      foodType
    } = e.detail.value;
    if (priceStart === "" || priceEnd === "") {
      wx.showModal({
        title: '提示',
        content: '请输入价格区间',
      });
      return;
    }
    if (isNaN(priceStart) || isNaN(priceEnd)) {
      wx.showModal({
        title: '提示',
        content: '请输入数字',
      });
      return;
    }
    if (Number(priceStart) >= Number(priceEnd)) {
      wx.showModal({
        title: '提示',
        content: '下限不能高于或等于上限',
      });
      return;
    }

    // 筛选数据
    if (foodMode === "正常模式") {
      // 正常模式下 筛选价格和种类
      const targetType = foodsort.find(item => item.type === foodType);
      const filtered = targetType.list.filter(item => (Number(item.price) >= Number(priceStart) && Number(item.price) <= priceEnd));
      if (filtered.length < 1) {
        wx.showModal({
          title: '提示',
          content: '筛选结果为空，请调整筛选条件',
        });
        return;
      }
      const filteredWithColor = filtered.map((item, index) => ({
        ...item,
        color: colorArr[index]
      }))
      const jueding = [{
        id: 0,
        option: '中午吃什么？（正常模式）',
        awards: filteredWithColor,
      }];
      wx.setStorageSync('myJuedin', jueding);
    } else {
      // 只筛选价格区间 把所有菜品取出来 根据卡路里筛选
      // 先把所有菜品取出来
      const nestedArr = foodsort.map(item => item.list);
      const allFood = nestedArr.reduce((acc, cur) => acc.concat(cur), []);
      
      const priceControl = allFood.filter(item => (Number(item.price) >= Number(priceStart) && Number(item.price) <= priceEnd));
      let calorieControl = [];
      // 这里不知道另外那三种模式根据什么维度进行判断 所以随机取10个值出来以达到效果
      calorieControl = getRandomElements(priceControl, 10);

      if (calorieControl.length < 1){
        wx.showModal({
          title: '提示',
          content: '筛选结果为空，请调整筛选条件',
        });
        return;
      }
      
      const withColor = calorieControl.map(item => {
        const randomNumber = getRandomInteger(0, 16);
        return {
          ...item,
          color: colorArr[randomNumber],
        }
      });

      const jueding = [{
        id: 0,
        option: `中午吃什么？（${foodMode}模式）`,
        awards: withColor,
      }];
      wx.setStorageSync('myJuedin', jueding);
    }

    wx.switchTab({
      url: '../index/index'
    })
  },
})