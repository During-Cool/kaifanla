module.exports = [
   {
      id: 0,
      option: '中午吃什么？',
      awards: [
         {
            name: "黄焖鸡米饭",
            color: '#FFA827'
         },
         {
            name: "拌面扁肉",
            color: '#AA47BC'
         },
         {
            name: "自己多少斤心里没点数",
            color: '#42A5F6'
         },
         {
            name: "寿司",
            color: '#00CED1'
         },
         {
            name: "蛋炒饭",
            color: '#66BB6A'
         },
         {
            name: "兰州拉面",
            color: '#FFC928'
         },
         {
            name: "沙县小吃",
            color: '#FFA500'
         },
         {
            name: "麻辣烫",
            color: '#FF4500'
         },
         {
            name: "老坛酸菜牛肉面",
            color: '#FFB6C1'
         }
      ]
   },
]