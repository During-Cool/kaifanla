# 运行指南

- app.js中的wx.cloud.init需替换为自己的云开发环境id
- 数据库中创建一张user2表和一张mealRecord表即可
- 菜品可以在 /utils/foodsort.js中维护

